import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.BevelBorder;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class Question extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	public static String driver, url;
	public static Connection conn;
	public static Statement stmt;
	public static ResultSet rs;
	static int num;
	
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:parmacy db";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/parmacy db?useUnicode=yes&characterEncoding=UTF-8";
        String sql = "select * From noticeboard";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement();

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}
	/**
	 * Launch the application.
	 */
	

/**
	 * Create the frame.
	 */
	public Question() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Question.class.getResource("/image/speech-bubble-1.png")));
		setTitle("\uBB38\uC758\uAE00 \uC791\uC131");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 557, 353);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uBB38\uC758\uAE00 \uC791\uC131");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 25));
		lblNewLabel.setBounds(0, 0, 541, 36);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uAD00\uB9AC\uC790\uAC00 \uBCFC\uC218\uC788\uB294 \uAE00\uC785\uB2C8\uB2E4.");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setForeground(Color.RED);
		lblNewLabel_1.setBounds(331, 286, 198, 15);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("\uB4F1\uB85D");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				SimpleDateFormat date1 = new SimpleDateFormat("YY-MM-dd");
				String format_date1 = date1.format(System.currentTimeMillis());
				String title = textField_1.getText();
				String str = textField.getText();
				try {
					if(MainScreen.id==null)
					{
						MainScreen.id = "��ȸ��";
					}
					query("insert", "insert into noticeboard values('"+title+"','"+str+"','"+format_date1+"','"+MainScreen.id+"')");
					JOptionPane.showMessageDialog(null, "���������� ��ϵǾ����ϴ�!","�˸��޽���",JOptionPane.INFORMATION_MESSAGE);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
		btnNewButton.setToolTipText("\uBCF4\uB0B4\uAE30");
		btnNewButton.setBounds(432, 253, 97, 23);
		contentPane.add(btnNewButton);
		
		
		ImageIcon icon4 = new ImageIcon(MainScreen.class.getResource("/image/images.png"));
		Image img4 = icon4.getImage();
		Image changeImg4 = img4.getScaledInstance(60, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon3 = new ImageIcon(changeImg4);
		JButton btnNewButton_1 = new JButton(changeIcon3);
		btnNewButton_1.setToolTipText("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setBounds(12, 278, 36, 23);
		contentPane.add(btnNewButton_1);
		
		SimpleDateFormat date1 = new SimpleDateFormat("YY�� MM�� dd��");
		String format_date1 = date1.format(System.currentTimeMillis());
		JLabel lblNewLabel_1_2 = new JLabel(format_date1);
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setFont(new Font("���� ����", Font.PLAIN, 14));
		lblNewLabel_1_2.setBounds(361, 32, 168, 29);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_2 = new JLabel("\uB0B4\uC6A9");
		lblNewLabel_2.setBounds(12, 142, 57, 15);
		contentPane.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(14, 167, 515, 58);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_2_1 = new JLabel("\uC81C\uBAA9");
		lblNewLabel_2_1.setBounds(12, 71, 57, 15);
		contentPane.add(lblNewLabel_2_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(14, 96, 515, 36);
		contentPane.add(textField_1);
		
		
	}
}
