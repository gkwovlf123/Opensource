import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;

import java.awt.Color;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.border.BevelBorder;
import javax.swing.ListSelectionModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class AccountCheck_1 extends JFrame {

	private JPanel contentPane;
	private JTable table;
	public static String driver, url;
	public static Connection conn;
	public static Statement stmt;
	public static ResultSet rs;
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:parmacy db";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/parmacy db?useUnicode=yes&characterEncoding=UTF-8";
        String sql = "select * From customer";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement();

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}
	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public AccountCheck_1() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(AccountCheck_1.class.getResource("/image/phone-book-1.png")));
		setTitle("\uAC70\uB798\uCC98\uBAA9\uB85D\uC870\uD68C");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 619, 320);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uAC70\uB798\uCC98\uBAA9\uB85D\uC870\uD68C");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 25));
		lblNewLabel.setBounds(0, 0, 603, 44);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 54, 558, 194);
		contentPane.add(scrollPane_1);
		
		String[] head = {"�ŷ�ó ID", "�ŷ�ó �̸�", "�ּ�","��ȭ��ȣ"};
		DefaultTableModel model = new DefaultTableModel(head,0);
			try {
				dbConnect();
				query("select", "select * from customer");
				while(rs.next()) {
					model.addRow(new Object[] {rs.getString("cus_id"),
												rs.getString("cus_name"),
												rs.getString("cus_address"),
												rs.getString("cus_number")
												});
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			Main.dbDis();
		table = new JTable(model);
		scrollPane_1.setViewportView(table);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setColumnSelectionAllowed(true);
		table.setCellSelectionEnabled(true);
		table.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		
		SimpleDateFormat date1 = new SimpleDateFormat("YY�� MM�� dd��");
		String format_date1 = date1.format(System.currentTimeMillis());
		JLabel lblNewLabel_1_2 = new JLabel(format_date1);
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setFont(new Font("���� ����", Font.PLAIN, 14));
		lblNewLabel_1_2.setBounds(423, 29, 168, 15);
		contentPane.add(lblNewLabel_1_2);
		
		ImageIcon icon4 = new ImageIcon(MainScreen.class.getResource("/image/images.png"));
		Image img4 = icon4.getImage();
		Image changeImg4 = img4.getScaledInstance(60, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon3 = new ImageIcon(changeImg4);
		JButton btnNewButton_1_2 = new JButton(changeIcon3);
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton_1_2.setToolTipText("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1_2.setBackground(Color.WHITE);
		btnNewButton_1_2.setBounds(0, 258, 36, 23);
		contentPane.add(btnNewButton_1_2);
	}
}
