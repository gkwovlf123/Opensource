import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.text.SimpleDateFormat;

import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.JButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class noticeboard extends JFrame {

	private JPanel contentPane;
	private JTable table;
	public static String driver, url;
	public static Connection conn;
	public static Statement stmt;
	public static ResultSet rs;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:parmacy db";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/parmacy db?useUnicode=yes&characterEncoding=UTF-8";
        String sql = "select * From noticeboard";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement();

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public noticeboard() {
		setTitle("\uAC8C\uC2DC\uD310");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 771, 432);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uAC8C\uC2DC\uD310");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 25));
		lblNewLabel.setBounds(0, 0, 755, 36);
		contentPane.add(lblNewLabel);
		
		SimpleDateFormat date1 = new SimpleDateFormat("YY�� MM�� dd��");
		String format_date1 = date1.format(System.currentTimeMillis());
		JLabel lblNewLabel_1_2 = new JLabel(format_date1);
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setFont(new Font("���� ����", Font.PLAIN, 14));
		lblNewLabel_1_2.setBounds(587, 36, 168, 15);
		contentPane.add(lblNewLabel_1_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 59, 755, 220);
		contentPane.add(scrollPane);
		String[] head = {"����", "����", "�ۼ���","����ID"};
		DefaultTableModel model = new DefaultTableModel(head,0);
		dbConnect();
			try {
				query("select", "select * from noticeboard");
				while(rs.next()) {
					model.addRow(new Object[] {rs.getString("n_title"),
												rs.getString("n_string"),
												rs.getString("n_date"),
												rs.getString("n_user"),
												});
				}
				
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("�����ͺ��̽� ���� ����!");
			}
			Main.dbDis();
		table = new JTable(model);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				TableModel data = table.getModel();
				String Title = (String)data.getValueAt(row, 0);
				
				dbConnect();
				try {
					query("select", "select * from noticeboard where n_title like '" + Title + "'");
					if(rs.next())
					{
						textField.setText(rs.getString("n_title"));
						textField_1.setText(rs.getString("n_string"));
						textField_2.setText(rs.getString("n_date"));
						textField_3.setText(rs.getString("n_user"));
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		scrollPane.setViewportView(table);
		
		ImageIcon icon4 = new ImageIcon(MainScreen.class.getResource("/image/images.png"));
		Image img4 = icon4.getImage();
		Image changeImg4 = img4.getScaledInstance(60, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon3 = new ImageIcon(changeImg4);
		JButton btnNewButton_1 = new JButton(changeIcon3);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Login_MainScreen().setVisible(true);
			}
		});
		btnNewButton_1.setToolTipText("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setBounds(12, 360, 36, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("\uAC8C\uC2DC\uD310\uC5D0 \uAE00 \uC801\uAE30");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Question().setVisible(true);
				
			}
		});
		btnNewButton.setBounds(605, 360, 138, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("\uAE00 \uC0AD\uC81C");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				if(MainScreen.id.equals("admin"))
				{
					String title = textField.getText();
					try {
						query("delete","delete from noticeboard where n_title like '" + title + "'");
						JOptionPane.showMessageDialog(null, "���������� �����Ǿ����ϴ�! �ٽ� �����ø� ����˴ϴ�!.", "�����޽���", JOptionPane.INFORMATION_MESSAGE);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
				}
				Main.dbDis();
				}
				else {
					btnNewButton_2.enable(false);
					JOptionPane.showMessageDialog(null, "�ش� ����� �����ڸ� �̿� �� �� �ֽ��ϴ�!", "����޽���", JOptionPane.ERROR_MESSAGE);
					
				}
				
			}
		});
		btnNewButton_2.setBounds(482, 360, 97, 23);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel_1 = new JLabel("\uC81C\uBAA9");
		lblNewLabel_1.setBounds(31, 292, -7, 15);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(51, 289, -7, 21);
		contentPane.add(textField);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("\uB0B4\uC6A9");
		lblNewLabel_1_1_1.setBounds(143, 292, 0, 15);
		contentPane.add(lblNewLabel_1_1_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(171, 289, 0, 21);
		contentPane.add(textField_1);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("\uC791\uC131\uC77C");
		lblNewLabel_1_1_1_1_1.setBounds(276, 292, 0, 15);
		contentPane.add(lblNewLabel_1_1_1_1_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(336, 289, 0, 21);
		contentPane.add(textField_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("\uC720\uC800ID");
		lblNewLabel_1_1.setBounds(15, 317, 0, 15);
		contentPane.add(lblNewLabel_1_1);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(51, 314, 0, 21);
		contentPane.add(textField_3);
	}
}
