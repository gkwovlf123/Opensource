import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
public class InventoryCheak extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTable table;
	private JTable table_1;
	public static String driver, url;
	public static Connection conn;
	public static Statement stmt;
	public static ResultSet rs;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:parmacy db";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/parmacy db?useUnicode=yes&characterEncoding=UTF-8";
        String sql = "select * From inventory";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement();

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public InventoryCheak() {
		setTitle("\uC7AC\uACE0\uBAA9\uB85D\uC870\uD68C");
		setIconImage(Toolkit.getDefaultToolkit().getImage(InventoryCheak.class.getResource("/image/document-3.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 615, 465);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		String[] head = {"��ǰ ID", "�� �̸�", "������¥","����","����","����ȸ���ڵ�"};
		DefaultTableModel model = new DefaultTableModel(head,0);
			
			try {
				dbConnect();
				query("select", "select * from inventory");
				while(rs.next()) {
					model.addRow(new Object[] {rs.getString("in_id"),
												rs.getString("in_name"),
												rs.getString("in_date"),
												rs.getString("in_count"),
												rs.getString("in_salary"),
												rs.getString("in_cusid")
												});
				}
				
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("�����ͺ��̽� ���� ����!");
			}
			Main.dbDis();
		table_1 = new JTable(model);
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table_1.getSelectedRow();
				TableModel data = table_1.getModel();
				String id = (String)data.getValueAt(row, 0);
				dbConnect();
				try {
					query("select", "select * from inventory where in_id like '" + id + "'");
					if(rs.next())
					{
						textField.setText(rs.getString("in_id"));
						textField_3.setText(rs.getString("in_name"));
						textField_2.setText(rs.getString("in_date"));
						textField_1.setText(rs.getString("in_count"));
						textField_4.setText(rs.getString("in_salary"));
						textField_6.setText(rs.getString("in_cusid"));
						textField_5.setText((rs.getString("in_comment")));
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
				
			}
		});
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 80, 560, 187);
		scrollPane.setViewportView(table_1);
		contentPane.add(scrollPane);
		
		
		JLabel lblNewLabel = new JLabel("\uC7AC\uACE0\uBAA9\uB85D\uC870\uD68C");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 25));
		lblNewLabel.setBounds(0, 0, 603, 44);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uC57D\uD488 ID");
		lblNewLabel_1.setBounds(14, 288, 39, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("\uC774\uB984");
		lblNewLabel_1_1.setBounds(29, 313, 24, 15);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("\uAC1C\uC218");
		lblNewLabel_1_1_1.setBounds(157, 288, 24, 15);
		contentPane.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("\uAC00\uACA9");
		lblNewLabel_1_1_1_1.setBounds(157, 313, 24, 15);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("\uC81C\uC870\uC77C\uC790");
		lblNewLabel_1_1_1_1_1.setBounds(290, 288, 48, 15);
		contentPane.add(lblNewLabel_1_1_1_1_1);
		
		textField = new JTextField();
		textField.setBounds(65, 285, 80, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(185, 285, 80, 21);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(350, 285, 80, 21);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(65, 310, 80, 21);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setHorizontalAlignment(SwingConstants.LEFT);
		textField_4.setColumns(10);
		textField_4.setBounds(185, 310, 80, 21);
		contentPane.add(textField_4);
		
		JButton btnNewButton = new JButton("\uC800\uC7A5");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String id = textField.getText();
				String name = textField_3.getText();
				String date = textField_2.getText();
				String count = textField_1.getText();
				String price = textField_4.getText();
				String comment = textField_5.getText();
				String cusid = textField_6.getText();
				Date d = Date.valueOf(date);
				try {
					query("insert", "insert into inventory values('" + id + "','" + name + "','" + d + "','" + count + "','" + price + "','" + cusid + "','" + comment + "')");
					JOptionPane.showMessageDialog(null, "��ǰ��ϿϷ�", "�˸� �޽���", JOptionPane.INFORMATION_MESSAGE);
					textField.setText("");
					textField_3.setText("");
					textField_2.setText("");
					textField_1.setText("");
					textField_4.setText("");
					textField_5.setText("");
					textField_6.setText("");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		btnNewButton.setToolTipText("\uC800\uC7A5\uD558\uAE30");
		btnNewButton.setBounds(477, 284, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uC218\uC815");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String id = textField.getText();
				String name = textField_3.getText();
				String date = textField_2.getText();
				String count = textField_1.getText();
				String price = textField_4.getText();
				String comment = textField_5.getText();
				String cusid = textField_6.getText();
				Date d = Date.valueOf(date);
				try {
					query("update", "update inventory set in_ID ='"+id+"', in_Name = '"+name +"', in_Date ='"+d+"', in_Count ='"+count+"', in_Salary ='"+price+"', in_Cusid ='"+cusid+"', in_comment ='"+comment+"' where in_ID like '"+id+"'");
					JOptionPane.showMessageDialog(null, "���������� �����Ǿ����ϴ�!.", "�����޽���", JOptionPane.INFORMATION_MESSAGE);
					textField.setText("");
					textField_3.setText("");
					textField_2.setText("");
					textField_1.setText("");
					textField_4.setText("");
					textField_5.setText("");
					textField_6.setText("");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		btnNewButton_1.setToolTipText("\uC218\uC815\uD558\uAE30");
		btnNewButton_1.setBounds(477, 335, 97, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("\uC0AD\uC81C");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String id = textField.getText();
				try {
					query("delete","delete from inventory where in_id like '" + id + "'");
					JOptionPane.showMessageDialog(null, "���������� �����Ǿ����ϴ�! �ٽ� �����ø� ����˴ϴ�!.", "�����޽���", JOptionPane.INFORMATION_MESSAGE);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		btnNewButton_1_1.setToolTipText("\uC0AD\uC81C\uD558\uAE30");
		btnNewButton_1_1.setBounds(477, 385, 97, 23);
		contentPane.add(btnNewButton_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("\uC57D\uC758 \uC815\uBCF4");
		lblNewLabel_1_1_2.setBounds(12, 371, 52, 15);
		contentPane.add(lblNewLabel_1_1_2);
		
		SimpleDateFormat date1 = new SimpleDateFormat("YY�� MM�� dd��");
		String format_date1 = date1.format(System.currentTimeMillis());
		JLabel lblNewLabel_1_2 = new JLabel(format_date1);
		lblNewLabel_1_2.setFont(new Font("���� ����", Font.PLAIN, 14));
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setBounds(423, 22, 168, 15);
		contentPane.add(lblNewLabel_1_2);
		
		ImageIcon icon4 = new ImageIcon(MainScreen.class.getResource("/image/images.png"));
		Image img4 = icon4.getImage();
		Image changeImg4 = img4.getScaledInstance(60, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon3 = new ImageIcon(changeImg4);
		JButton btnNewButton_1_2 = new JButton(changeIcon3);
		btnNewButton_1_2.setToolTipText("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Login_MainScreen().setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton_1_2.setBackground(Color.WHITE);
		btnNewButton_1_2.setBounds(12, 396, 36, 23);
		contentPane.add(btnNewButton_1_2);
		
		textField_5 = new JTextField();
		textField_5.setBounds(65, 368, 394, 21);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("\uC81C\uC870\uD68C\uC0AC\uCF54\uB4DC");
		lblNewLabel_1_1_1_1_1_1.setBounds(277, 313, 72, 15);
		contentPane.add(lblNewLabel_1_1_1_1_1_1);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(350, 310, 80, 21);
		contentPane.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setBounds(383, 56, 116, 21);
		contentPane.add(textField_7);
		textField_7.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("\uAC80\uC0C9");
		lblNewLabel_2.setBounds(350, 59, 24, 15);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton_2 = new JButton("\uAC80\uC0C9");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String SearchData = textField_7.getText();
				model.setNumRows(0);
				try {
					query("select", "select * from inventory where in_name like '%"+SearchData+"%'");
					while(rs.next())
					{
						
						model.addRow(new Object[] {rs.getString("in_id"),
												   rs.getString("in_name"),
												   rs.getString("in_date"),
												   rs.getString("in_count"),
												   rs.getString("in_salary"),
												   rs.getString("in_cusid")
											});
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		btnNewButton_2.setBounds(511, 54, 63, 23);
		contentPane.add(btnNewButton_2);
	}
}
