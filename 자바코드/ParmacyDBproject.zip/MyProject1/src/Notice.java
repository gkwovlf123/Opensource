import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Toolkit;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Notice extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public Notice() {
		setTitle("\uACBD\uACE0\uCC3D");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Notice.class.getResource("/image/cancel.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 317, 163);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uC815\uB9D0 \uB85C\uADF8\uC544\uC6C3 \uD558\uC2DC\uACA0\uC2B5\uB2C8\uAE4C?");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 16));
		lblNewLabel.setBounds(61, 21, 228, 52);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("\uC608");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainScreen.id = null;
				setVisible(false);
				new MainScreen().setVisible(true);
			}
		});
		btnNewButton.setBounds(43, 83, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uC544\uB2C8\uC624");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Login_MainScreen().setVisible(true);
			}
		});
		btnNewButton_1.setBounds(163, 83, 97, 23);
		contentPane.add(btnNewButton_1);
		
		ImageIcon icon1 = new ImageIcon(Login_MainScreen.class.getResource("/image/cancel.png"));
		Image img1 = icon1.getImage();
		Image changeImg1 = img1.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon1 = new ImageIcon(changeImg1);
		JLabel lblNewLabel_1 = new JLabel(changeIcon1);
		lblNewLabel_1.setBounds(22, 21, 49, 52);
		contentPane.add(lblNewLabel_1);
	}

}
