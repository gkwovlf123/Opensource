import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.border.BevelBorder;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AccountCheck extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	public static String driver, url;
	public static Connection conn;
	public static Statement stmt;
	public static ResultSet rs;
	
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:parmacy db";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/parmacy db?useUnicode=yes&characterEncoding=UTF-8";
        String sql = "select * From customer";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement();

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public AccountCheck() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(AccountCheck.class.getResource("/image/phone-book-1.png")));
		setTitle("\uAC70\uB798\uCC98\uBAA9\uB85D\uC870\uD68C");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 615, 465);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uAC70\uB798\uCC98\uBAA9\uB85D\uC870\uD68C");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 25));
		lblNewLabel.setBounds(0, 0, 603, 44);
		contentPane.add(lblNewLabel);
		
		SimpleDateFormat date1 = new SimpleDateFormat("YY�� MM�� dd��");
		String format_date1 = date1.format(System.currentTimeMillis());
		JLabel lblNewLabel_1_2 = new JLabel(format_date1);
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setFont(new Font("���� ����", Font.PLAIN, 14));
		lblNewLabel_1_2.setBounds(423, 22, 168, 15);
		contentPane.add(lblNewLabel_1_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 80, 560, 187);
		contentPane.add(scrollPane);
		
		
		String[] head = {"�ŷ�ó ID", "�ŷ�ó �̸�", "�ּ�","��ȭ��ȣ"};
		DefaultTableModel model = new DefaultTableModel(head,0);
			try {
				dbConnect();
				query("select", "select * from customer");
				while(rs.next()) {
					model.addRow(new Object[] {rs.getString("cus_id"),
												rs.getString("cus_name"),
												rs.getString("cus_address"),
												rs.getString("cus_number")
												});
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			Main.dbDis();
		table = new JTable(model);
		scrollPane.setViewportView(table);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				TableModel data = table.getModel();
				String id = (String)data.getValueAt(row, 0);
				dbConnect();
				try {
					query("select", "select * from customer where cus_id like '" + id + "'");
					if(rs.next())
					{
						textField_2.setText(rs.getString("cus_id"));
						textField.setText(rs.getString("cus_name"));
						textField_3.setText(rs.getString("cus_address"));
						textField_1.setText(rs.getString("cus_number"));
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
				
			}
		});
		
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setColumnSelectionAllowed(true);
		table.setCellSelectionEnabled(true);
		table.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		
		JLabel lblNewLabel_1_1_1 = new JLabel("\uC774\uB984");
		lblNewLabel_1_1_1.setBounds(177, 293, 24, 15);
		contentPane.add(lblNewLabel_1_1_1);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(213, 290, 130, 21);
		contentPane.add(textField);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("\uC804\uD654\uBC88\uD638");
		lblNewLabel_1_1_1_1.setBounds(210, 333, 48, 15);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(265, 330, 130, 21);
		contentPane.add(textField_1);
		
		JLabel lblNewLabel_1 = new JLabel("\uAC70\uB798\uCC98 ID");
		lblNewLabel_1.setBounds(10, 293, 51, 15);
		contentPane.add(lblNewLabel_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(71, 290, 80, 21);
		contentPane.add(textField_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("\uC8FC\uC18C");
		lblNewLabel_1_1.setBounds(32, 333, 24, 15);
		contentPane.add(lblNewLabel_1_1);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(68, 330, 130, 21);
		contentPane.add(textField_3);
		
		JButton btnNewButton = new JButton("\uC800\uC7A5");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String id = textField_2.getText();
				String name = textField.getText();
				String addr = textField_3.getText();
				String number = textField_1.getText();
				try {
					query("insert", "insert into customer values('" + id + "','" + name + "','" + addr + "','" + number +"')");
					JOptionPane.showMessageDialog(null, "�ŷ�ó��ϿϷ�", "�˸� �޽���", JOptionPane.INFORMATION_MESSAGE);
					textField_2.setText("");
					textField.setText("");
					textField_3.setText("");
					textField_1.setText("");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		btnNewButton.setToolTipText("\uC800\uC7A5\uD558\uAE30");
		btnNewButton.setBounds(473, 277, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uC218\uC815");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String id = textField_2.getText();
				String name = textField.getText();
				String addr = textField_3.getText();
				String number = textField_1.getText();
				try {
					query("update", "update customer set cus_id ='"+id+"', cus_name = '"+name +"', cus_address ='"+addr+"', cus_number ='"+number+"' where cus_id like '"+id+"'");
					JOptionPane.showMessageDialog(null, "���������� �����Ǿ����ϴ�! �ٽ� �����ø� ����˴ϴ�!", "�����޽���", JOptionPane.INFORMATION_MESSAGE);
					textField_2.setText("");
					textField.setText("");
					textField_3.setText("");
					textField_1.setText("");
	
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		btnNewButton_1.setToolTipText("\uC218\uC815\uD558\uAE30");
		btnNewButton_1.setBounds(473, 328, 97, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("\uC0AD\uC81C");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String id = textField_2.getText();
				try {
					query("delete","delete from customer where cus_id like '" + id + "'");
					JOptionPane.showMessageDialog(null, "���������� �����Ǿ����ϴ�! �ٽ� �����ø� ����˴ϴ�!.", "�����޽���", JOptionPane.INFORMATION_MESSAGE);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		btnNewButton_1_1.setToolTipText("\uC0AD\uC81C\uD558\uAE30");
		btnNewButton_1_1.setBounds(473, 378, 97, 23);
		contentPane.add(btnNewButton_1_1);
		
		ImageIcon icon4 = new ImageIcon(MainScreen.class.getResource("/image/images.png"));
		Image img4 = icon4.getImage();
		Image changeImg4 = img4.getScaledInstance(60, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon3 = new ImageIcon(changeImg4);
		JButton btnNewButton_1_2 = new JButton(changeIcon3);
		btnNewButton_1_2.setToolTipText("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Login_MainScreen().setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton_1_2.setBackground(Color.WHITE);
		btnNewButton_1_2.setBounds(10, 393, 36, 23);
		contentPane.add(btnNewButton_1_2);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(379, 56, 116, 21);
		contentPane.add(textField_4);
		
		JLabel lblNewLabel_2 = new JLabel("\uAC80\uC0C9");
		lblNewLabel_2.setBounds(346, 59, 24, 15);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton_2 = new JButton("\uAC80\uC0C9");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String SearchData = textField_4.getText();
				model.setNumRows(0);
				try {
					query("select", "select * from customer where cus_name like '%"+SearchData+"%'");
					while(rs.next())
					{
						
						model.addRow(new Object[] {rs.getString("cus_id"),
												   rs.getString("cus_name"),
												   rs.getString("cus_address"),
												   rs.getString("cus_number"),
											});
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		btnNewButton_2.setBounds(507, 54, 63, 23);
		contentPane.add(btnNewButton_2);
	}
}
