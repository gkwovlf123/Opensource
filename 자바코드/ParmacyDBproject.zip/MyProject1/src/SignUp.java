import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Toolkit;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JFormattedTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Random;

public class SignUp extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	static JTextField textField_1;
	private JTextField textField_2;
	public static String driver, url;
	public static Connection conn;
	public static Statement stmt;
	public static ResultSet rs;
	String id;
	String pw;
	String email;
	
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:parmacy db";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/parmacy db";
        String sql = "select * From member";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement();

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public SignUp() {
		setTitle("\uD68C\uC6D0\uAC00\uC785");
		setIconImage(Toolkit.getDefaultToolkit().getImage(SignUp.class.getResource("/image/group.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\uD68C\uC6D0 \uAC00\uC785 ");
		lblNewLabel.setBounds(5, 5, 434, 30);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 25));
		
		JLabel lblNewLabel_1 = new JLabel("* \uB294 \uD544\uC218\uC785\uB825");
		lblNewLabel_1.setBounds(353, 45, 74, 15);
		lblNewLabel_1.setForeground(Color.RED);
		
		JLabel lblNewLabel_2 = new JLabel("* ID");
		lblNewLabel_2.setBounds(108, 96, 25, 20);
		lblNewLabel_2.setFont(new Font("���� ����", Font.PLAIN, 14));
		
		JLabel lblNewLabel_2_1 = new JLabel("* PW");
		lblNewLabel_2_1.setBounds(100, 139, 32, 20);
		lblNewLabel_2_1.setFont(new Font("���� ����", Font.PLAIN, 14));
		
		JLabel lblNewLabel_2_2 = new JLabel("* E-Mail");
		lblNewLabel_2_2.setBounds(82, 180, 50, 20);
		lblNewLabel_2_2.setFont(new Font("���� ����", Font.PLAIN, 14));
		
		ImageIcon icon5 = new ImageIcon(MainScreen.class.getResource("/image/images.png"));
		Image img5 = icon5.getImage();
		Image changeImg5 = img5.getScaledInstance(60, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon4 = new ImageIcon(changeImg5);
		JButton btnNewButton = new JButton(changeIcon4);
		btnNewButton.setToolTipText("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new MainScreen().setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton.setBounds(5, 228, 36, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBackground(Color.ORANGE);
		btnNewButton.setForeground(Color.BLACK);
		
		textField = new JTextField();
		textField.setBounds(156, 98, 108, 21);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				new SignUp_Pw().setVisible(true);
				
			}
		});
		textField_1.setBounds(155, 141, 108, 21);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(155, 182, 108, 21);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_2_3 = new JLabel("* \uBB38\uC790 + \uC22B\uC790 10\uC790 \uC774\uB0B4");
		lblNewLabel_2_3.setBounds(276, 96, 113, 14);
		lblNewLabel_2_3.setFont(new Font("���� ����", Font.PLAIN, 10));
		
		JLabel lblNewLabel_2_3_1 = new JLabel("* \uC22B\uC790 10\uC790 \uC774\uB0B4");
		lblNewLabel_2_3_1.setBounds(275, 139, 113, 14);
		lblNewLabel_2_3_1.setFont(new Font("���� ����", Font.PLAIN, 10));
		contentPane.setLayout(null);
		contentPane.add(lblNewLabel);
		contentPane.add(lblNewLabel_1);
		contentPane.add(lblNewLabel_2);
		contentPane.add(lblNewLabel_2_1);
		contentPane.add(lblNewLabel_2_2);
		contentPane.add(btnNewButton);
		contentPane.add(textField);
		contentPane.add(textField_1);
		contentPane.add(textField_2);
		contentPane.add(lblNewLabel_2_3);
		contentPane.add(lblNewLabel_2_3_1);
		
		JButton btnNewButton_1 = new JButton("\uB4F1\uB85D");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				Random r = new Random();
				int usercode = r.nextInt(10000);
				if(usercode<1000)
				{
					while(true)
					{
						if(usercode<1000)
						{
							usercode = r.nextInt(10000);
						}
					}
				}
				id = textField.getText();
				pw = textField_1.getText();
				email = textField_2.getText();
				try {
					query("insert", "insert into member values('" + id + "','" + pw + "','" + email + "','" + usercode + "')");
					JOptionPane.showMessageDialog(null, "ȸ�����ԿϷ� ������ �����ڵ� : "+usercode, "�˸� �޽���", JOptionPane.INFORMATION_MESSAGE);
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		btnNewButton_1.setToolTipText("\uB4F1\uB85D\uD558\uAE30");
		btnNewButton_1.setBounds(177, 212, 65, 23);
		contentPane.add(btnNewButton_1);
		
		SimpleDateFormat date1 = new SimpleDateFormat("YY�� MM�� dd��");
		String format_date1 = date1.format(System.currentTimeMillis());
		JLabel lblNewLabel_1_2 = new JLabel(format_date1);
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setFont(new Font("���� ����", Font.PLAIN, 14));
		lblNewLabel_1_2.setBounds(254, 16, 168, 15);
		contentPane.add(lblNewLabel_1_2);
	}
}
