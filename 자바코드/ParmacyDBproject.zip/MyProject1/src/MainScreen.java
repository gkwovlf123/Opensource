import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import javax.swing.Icon;
import java.awt.SystemColor;
import javax.swing.UIManager;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.sql.*;

public class MainScreen extends JFrame{
	
	private JPanel contentPane;
	public static JTextField txtid;
	public static JTextField txtpw;
	public static JTextField txtemail;
	public static String driver, url;
	public static Connection conn;
	public static Statement stmt;
	public static ResultSet rs;
	static String id;
	String pw;
	String email;
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:parmacy db";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/parmacy db";
        String sql = "select * From member";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement();

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	
	public MainScreen() {
		
		setTitle("\uC57D\uAD6D \uC7AC\uACE0 \uAD00\uB9AC \uD504\uB85C\uADF8\uB7A8");
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainScreen.class.getResource("/image/images4MWKDB9U.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 586, 501);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\uC57D\uAD6D \uC7AC\uACE0 \uAD00\uB9AC \uD504\uB85C\uADF8\uB7A8");
		lblNewLabel.setBounds(10, 35, 555, 48);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 25));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setBounds(229, 246, 15, 22);
		lblNewLabel_1.setFont(new Font("���� ����", Font.PLAIN, 16));
		
		txtid = new JTextField();
		txtid.setBounds(256, 243, 88, 26);
		txtid.setBackground(Color.WHITE);
		txtid.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(255, 267, 2, 2);
		
		ImageIcon icon1 = new ImageIcon(MainScreen.class.getResource("/image/notification.png"));
		Image img1 = icon1.getImage();
		Image changeImg1 = img1.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon1 = new ImageIcon(changeImg1);
		JButton btnNewButton = new JButton(changeIcon1);
		btnNewButton.setToolTipText("\uBB38\uC758\uD558\uAE30");
		btnNewButton.setBounds(464, 326, 48, 39);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Question().setVisible(true);
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(Color.WHITE);
		
		
		ImageIcon icon = new ImageIcon(MainScreen.class.getResource("/image/group.png"));
		Image img = icon.getImage();
		Image changeImg = img.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon = new ImageIcon(changeImg);
		JButton btnNewButton_1 = new JButton(changeIcon);
		btnNewButton_1.setToolTipText("\uD68C\uC6D0\uAC00\uC785");
		btnNewButton_1.setBounds(465, 246, 48, 39);
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new SignUp().setVisible(true);
				setVisible(false);
			}
		});
		
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBackground(Color.WHITE);
		
		JLabel lblNewLabel_1_2 = new JLabel("\uD68C\uC6D0\uAC00\uC785");
		lblNewLabel_1_2.setBounds(465, 288, 48, 17);
		lblNewLabel_1_2.setForeground(Color.BLACK);
		lblNewLabel_1_2.setBackground(Color.WHITE);
		lblNewLabel_1_2.setFont(new Font("���� ����", Font.PLAIN, 12));
		
		JLabel lblNewLabel_1_2_1 = new JLabel("\uBB38\uC758\uD558\uAE30");
		lblNewLabel_1_2_1.setBounds(464, 367, 48, 17);
		lblNewLabel_1_2_1.setForeground(Color.BLACK);
		lblNewLabel_1_2_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		lblNewLabel_1_2_1.setBackground(Color.WHITE);
		
		txtpw = new JTextField();
		txtpw.setBounds(256, 287, 88, 25);
		txtpw.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new MainScreen_Pw().setVisible(true);
			}
		});
		txtpw.setColumns(10);
		txtpw.setBackground(Color.WHITE);
		
		
		ImageIcon icon3 = new ImageIcon(MainScreen.class.getResource("/image/png-transparent-pictogram-computer-icons-blue-pharmacy-phial-white-grey-cross-thumbnail.png"));
		Image img3 = icon3.getImage();
		Image changeImg3 = img3.getScaledInstance(60, 100, Image.SCALE_SMOOTH);
		ImageIcon changeIcon3 = new ImageIcon(changeImg3);
		JLabel lblNewLabel_2 = new JLabel(changeIcon3);
		lblNewLabel_2.setBounds(166, 93, 241, 116);
		
		JLabel lblNewLabel_1_3 = new JLabel("E-Mail");
		lblNewLabel_1_3.setBounds(198, 327, 46, 22);
		lblNewLabel_1_3.setFont(new Font("���� ����", Font.PLAIN, 16));
		
		JLabel lblNewLabel_1_1 = new JLabel("PW");
		lblNewLabel_1_1.setBounds(220, 287, 24, 22);
		lblNewLabel_1_1.setFont(new Font("���� ����", Font.PLAIN, 16));
		
		txtemail = new JTextField();
		txtemail.setBounds(256, 329, 88, 25);
		txtemail.setColumns(10);
		txtemail.setBackground(Color.WHITE);
		
		JButton btnNewButton_2 = new JButton("\uB85C\uADF8\uC778");
		btnNewButton_2.setToolTipText("\uB85C\uADF8\uC778");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				id = txtid.getText();
				id.trim();
				pw = txtpw.getText();
				email = txtemail.getText();
				String sql = "select * from member where mem_ID like '" + id + "'";
				try {
					rs = stmt.executeQuery(sql);
					if(rs.next())
					{
						if(pw.equals(rs.getString("mem_Pw")))
						{
							if(email.equals(rs.getString("mem_EMail")))
							{
								//if(id == "admin")
								//{
								//	
								//}
								setVisible(false);
								JOptionPane.showMessageDialog(null, "ȯ���մϴ�!" + id + "��!", "�˸��޽���", JOptionPane.INFORMATION_MESSAGE);
								
								new Login_MainScreen().setVisible(true);
							}
							else
							{
								JOptionPane.showMessageDialog(null, "�̸����� �����ʽ��ϴ�", "�����޽���",JOptionPane.ERROR_MESSAGE);
							}
						}
						else
						{
							JOptionPane.showMessageDialog(null, "��й�ȣ�� �����ʽ��ϴ�", "�����޽���",JOptionPane.ERROR_MESSAGE);
						}
					}
					else
					{
						JOptionPane.showMessageDialog(null, "���̵� �����ʰų� ��ȸ���̽ø� ȸ�������� �������ּ���", "�����޽���",JOptionPane.ERROR_MESSAGE);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
				
			}
		});
		btnNewButton_2.setBounds(256, 394, 88, 23);
		contentPane.setLayout(null);
		contentPane.add(lblNewLabel);
		contentPane.add(lblNewLabel_2);
		contentPane.add(lblNewLabel_1);
		contentPane.add(scrollPane);
		contentPane.add(txtid);
		contentPane.add(btnNewButton_1);
		contentPane.add(lblNewLabel_1_1);
		contentPane.add(txtpw);
		contentPane.add(lblNewLabel_1_2);
		contentPane.add(lblNewLabel_1_3);
		contentPane.add(btnNewButton_2);
		contentPane.add(txtemail);
		contentPane.add(btnNewButton);
		contentPane.add(lblNewLabel_1_2_1);
		
		SimpleDateFormat date1 = new SimpleDateFormat("YY�� MM�� dd��");
		String format_date1 = date1.format(System.currentTimeMillis());
		JLabel lblNewLabel_1_2_2 = new JLabel(format_date1);
		lblNewLabel_1_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2_2.setFont(new Font("���� ����", Font.PLAIN, 14));
		lblNewLabel_1_2_2.setBounds(402, 68, 168, 15);
		contentPane.add(lblNewLabel_1_2_2);
		
		JButton btnNewButton_3 = new JButton("PW \uCC3E\uAE30");
		btnNewButton_3.setToolTipText("PW \uCC3E\uAE30");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Forgot_PW().setVisible(true);
			}
		});
		btnNewButton_3.setBounds(355, 394, 89, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_3_1 = new JButton("ID \uCC3E\uAE30");
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Forgot_ID().setVisible(true);
			}
		});
		btnNewButton_3_1.setToolTipText("PW \uCC3E\uAE30");
		btnNewButton_3_1.setBounds(155, 394, 89, 23);
		contentPane.add(btnNewButton_3_1);
		
	}
}
