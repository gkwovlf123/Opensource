import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Info_Update extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField_3;
	private JLabel lblNewLabel_4;
	private JTextField textField_1;
	private JLabel lblNewLabel_2;
	private JTextField textField_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_1;
	public static String driver, url;
	public static Connection conn;
	public static Statement stmt;
	public static ResultSet rs;
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:parmacy db";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/parmacy db";
        String sql = "select * From member";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement();

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public Info_Update() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Info_Update.class.getResource("/image/zoom-in.png")));
		setTitle("\uC815\uBCF4\uC218\uC815");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 595, 263);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uC815\uBCF4\uC218\uC815");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 25));
		lblNewLabel.setBounds(0, 0, 579, 49);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 47, 400, 99);
		contentPane.add(scrollPane);
		table = new JTable();
		dbConnect();
		try {
			query("select", "select * from member where mem_id like '" + MainScreen.id + "'");
			while(rs.next()) 
			{
			table.setModel(new DefaultTableModel(	
					new Object[][] {
						{rs.getString("mem_id"), rs.getString("mem_pw"), rs.getString("mem_email")},
					},
					new String[] {
						"ID", "PW", "E-MAil"
					}
				));
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Main.dbDis();
		
		
		
		
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				TableModel data = table.getModel();
				String id = (String)data.getValueAt(row, 0);
				String pw = (String)data.getValueAt(row, 1);
				String email = (String)data.getValueAt(row, 2);
				try {
					dbConnect();
					query("select", "select * from member where mem_id like '" + id + "'");
					if(rs.next())
					{
						textField_3.setText(rs.getString("mem_id"));
						textField_1.setText(rs.getString("mem_pw"));
						textField_2.setText(rs.getString("mem_email"));
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
			
		});
		
		
		scrollPane.setViewportView(table);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(467, 51, 88, 21);
		contentPane.add(textField_3);
		
		lblNewLabel_4 = new JLabel("ID");
		lblNewLabel_4.setBounds(444, 54, 11, 15);
		contentPane.add(lblNewLabel_4);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(467, 88, 88, 21);
		contentPane.add(textField_1);
		
		lblNewLabel_2 = new JLabel("PW");
		lblNewLabel_2.setBounds(433, 91, 29, 15);
		contentPane.add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(467, 125, 88, 21);
		contentPane.add(textField_2);
		
		lblNewLabel_3 = new JLabel("E-Mail");
		lblNewLabel_3.setBounds(423, 131, 38, 15);
		contentPane.add(lblNewLabel_3);
		
		JButton btnNewButton = new JButton("\uC218\uC815");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				try {
					query("update", "update member set mem_ID ='"+textField_3.getText()+"', mem_Pw ='"+textField_1.getText()+"', mem_EMail ='"+textField_2.getText()+"' where mem_ID like '"+MainScreen.id+"'");
					JOptionPane.showMessageDialog(null, "�����Ǿ����ϴ� �ٽ� �α��� ���ֽʽÿ�.", "�����޽���", JOptionPane.INFORMATION_MESSAGE);
					setVisible(false);
					new MainScreen().setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		btnNewButton.setToolTipText("\uC218\uC815\uD558\uAE30");
		btnNewButton.setBounds(149, 177, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uD68C\uC6D0\uD0C8\uD1F4");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				try {
					query("delete", "delete from member where mem_id like '" + MainScreen.id + "'");
					JOptionPane.showMessageDialog(null, "���������� Ż��Ǿ����ϴ�.\n���񽺸� �̿����ּż� �����մϴ�.", "�����޽���", JOptionPane.INFORMATION_MESSAGE);
					setVisible(false);
					new MainScreen().setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		btnNewButton_1.setToolTipText("\uD68C\uC6D0\uD0C8\uD1F4");
		btnNewButton_1.setBounds(334, 177, 97, 23);
		contentPane.add(btnNewButton_1);
		
		ImageIcon icon5 = new ImageIcon(MainScreen.class.getResource("/image/images.png"));
		Image img5 = icon5.getImage();
		Image changeImg5 = img5.getScaledInstance(60, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon4 = new ImageIcon(changeImg5);
		JButton btnNewButton_2 = new JButton(changeIcon4);
		btnNewButton_2.setToolTipText("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Login_MainScreen().setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton_2.setBounds(12, 191, 36, 23);
		contentPane.add(btnNewButton_2);
		
		SimpleDateFormat date1 = new SimpleDateFormat("YY�� MM�� dd��");
		String format_date1 = date1.format(System.currentTimeMillis());
		lblNewLabel_1 = new JLabel(format_date1);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setFont(new Font("���� ����", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(411, 20, 168, 15);
		contentPane.add(lblNewLabel_1);
	}
}
