

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseEvent;

public class Login_MainScreen extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public Login_MainScreen() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Login_MainScreen.class.getResource("/image/images4MWKDB9U.png")));
		setTitle("\uC57D\uAD6D \uC7AC\uACE0 \uD655\uC778 \uD504\uB85C\uADF8\uB7A8");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 473, 408);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		ImageIcon icon4 = new ImageIcon(Login_MainScreen.class.getResource("/image/images.png"));
		Image img4 = icon4.getImage();
		Image changeImg4 = img4.getScaledInstance(60, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon4 = new ImageIcon(changeImg4);
		JButton btnNewButton = new JButton(changeIcon4);
		btnNewButton.setToolTipText("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Notice().setVisible(true);
			}
		});
		btnNewButton.setBounds(12, 10, 36, 23);
		contentPane.add(btnNewButton);
		
		ImageIcon icon3 = new ImageIcon(Login_MainScreen.class.getResource("/image/settings.png"));
		Image img3 = icon3.getImage();
		Image changeImg3 = img3.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon3 = new ImageIcon(changeImg3);
		
		ImageIcon icon2 = new ImageIcon(Login_MainScreen.class.getResource("/image/broken-heart.png"));
		Image img2 = icon2.getImage();
		Image changeImg2 = img2.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon2 = new ImageIcon(changeImg2);
		
		ImageIcon icon1 = new ImageIcon(Login_MainScreen.class.getResource("/image/notification.png"));
		Image img1 = icon1.getImage();
		Image changeImg1 = img1.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon1 = new ImageIcon(changeImg1);
		JButton btnNewButton_1_1_1 = new JButton(changeIcon1);
		btnNewButton_1_1_1.setToolTipText("\uBB38\uC758\uD558\uAE30");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new noticeboard().setVisible(true);
			}
		});
		btnNewButton_1_1_1.setBackground(Color.WHITE);
		btnNewButton_1_1_1.setBounds(206, 288, 48, 39
				);
		contentPane.add(btnNewButton_1_1_1);
		
		JLabel lblNewLabel_4 = new JLabel("\uAC8C\uC2DC\uD310");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("���� ����", Font.PLAIN, 12));
		lblNewLabel_4.setBounds(206, 325, 48, 15);
		contentPane.add(lblNewLabel_4);
		
		ImageIcon icon5 = new ImageIcon(Login_MainScreen.class.getResource("/image/document-3.png"));
		Image img5 = icon5.getImage();
		Image changeImg5 = img5.getScaledInstance(60, 60, Image.SCALE_SMOOTH);
		ImageIcon changeIcon5 = new ImageIcon(changeImg5);
		JButton btnNewButton_2 = new JButton(changeIcon5);
		btnNewButton_2.setToolTipText("\uC7AC\uACE0\uBAA9\uB85D\uC870\uD68C");
		
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new InventoryCheak().setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setBounds(148, 110, 80, 80);
		contentPane.add(btnNewButton_2);
		
		ImageIcon icon6 = new ImageIcon(Login_MainScreen.class.getResource("/image/document.png"));
		Image img6 = icon6.getImage();
		Image changeImg6 = img6.getScaledInstance(60, 60, Image.SCALE_SMOOTH);
		ImageIcon changeIcon6 = new ImageIcon(changeImg6);
		JButton btnNewButton_2_1 = new JButton(changeIcon6);
		btnNewButton_2_1.setToolTipText("\uBC1C\uC8FC\uBAA9\uB85D\uC870\uD68C");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "��ü��ǰ���� ������ 10�� ������ ��ǰ�� ���ɴϴ�.", "�˸� �޽���", JOptionPane.INFORMATION_MESSAGE);
				new OrderCheck().setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton_2_1.setBackground(Color.WHITE);
		btnNewButton_2_1.setBounds(227, 110, 80, 80);
		contentPane.add(btnNewButton_2_1);
		
		ImageIcon icon7 = new ImageIcon(Login_MainScreen.class.getResource("/image/phone-book-1.png"));
		Image img7 = icon7.getImage();
		Image changeImg7 = img7.getScaledInstance(60, 60, Image.SCALE_SMOOTH);
		ImageIcon changeIcon7 = new ImageIcon(changeImg7);
		JButton btnNewButton_2_2 = new JButton(changeIcon7);
		btnNewButton_2_2.setToolTipText("\uAC70\uB798\uCC98\uBAA9\uB85D");
		btnNewButton_2_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AccountCheck().setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton_2_2.setBackground(Color.WHITE);
		btnNewButton_2_2.setBounds(148, 187, 80, 80);
		contentPane.add(btnNewButton_2_2);
		
		JLabel lblNewLabel_3 = new JLabel("\uBA54\uC778\uD654\uBA74");
		lblNewLabel_3.setFont(new Font("���� ����", Font.PLAIN, 25));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(0, 22, 458, 49);
		contentPane.add(lblNewLabel_3);
		
		ImageIcon icon8 = new ImageIcon(Login_MainScreen.class.getResource("/image/zoom-in.png"));
		Image img8 = icon8.getImage();
		Image changeImg8 = img8.getScaledInstance(60, 60, Image.SCALE_SMOOTH);
		ImageIcon changeIcon8 = new ImageIcon(changeImg8);
		JButton btnNewButton_3 = new JButton(changeIcon8);
		btnNewButton_3.setToolTipText("\uC815\uBCF4\uC218\uC815");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Info_Update().setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton_3.setBackground(Color.WHITE);
		btnNewButton_3.setBounds(227, 187, 80, 80);
		contentPane.add(btnNewButton_3);
		
		SimpleDateFormat date1 = new SimpleDateFormat("YY�� MM�� dd��");
		String format_date1 = date1.format(System.currentTimeMillis());
		JLabel lblNewLabel_1_2 = new JLabel(format_date1);
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setFont(new Font("���� ����", Font.PLAIN, 14));
		lblNewLabel_1_2.setBounds(290, 56, 168, 15);
		contentPane.add(lblNewLabel_1_2);
	}
}
