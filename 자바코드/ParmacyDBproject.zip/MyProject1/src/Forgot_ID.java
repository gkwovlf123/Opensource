import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class Forgot_ID extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	public static String driver, url;
	public static Connection conn;
	public static Statement stmt;
	public static ResultSet rs;
	
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:parmacy db";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/parmacy db";
        String sql = "select * From member";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement();

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
		
	}
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}
	/**
	 * Launch the application.
	 */
	
	/**
	 * Create the frame.
	 */
	public Forgot_ID() {
		setTitle("ID \uCC3E\uAE30");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPw = new JLabel("ID \uCC3E\uAE30");
		lblPw.setHorizontalAlignment(SwingConstants.CENTER);
		lblPw.setFont(new Font("����", Font.BOLD, 25));
		lblPw.setBounds(0, 0, 434, 43);
		contentPane.add(lblPw);
		
		SimpleDateFormat date1 = new SimpleDateFormat("YY�� MM�� dd��");
		String format_date1 = date1.format(System.currentTimeMillis());
		JLabel lblNewLabel_1_2 = new JLabel(format_date1);
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setFont(new Font("���� ����", Font.PLAIN, 14));
		lblNewLabel_1_2.setBounds(266, 28, 168, 15);
		contentPane.add(lblNewLabel_1_2);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(165, 71, 116, 21);
		contentPane.add(textField);
		
		JLabel lblNewLabel = new JLabel("\uC720\uC800\uCF54\uB4DC");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 15));
		lblNewLabel.setBounds(97, 72, 56, 18);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uBCF8\uC778\uC758 \uC720\uC800\uCF54\uB4DC\uB97C \uC785\uB825\uD558\uC2DC\uC624 ");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setForeground(Color.GRAY);
		lblNewLabel_1.setBounds(107, 102, 174, 15);
		contentPane.add(lblNewLabel_1);
		
		JButton btnId = new JButton("ID \uCC3E\uAE30");
		btnId.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String usercode = textField.getText();
				try {
					query("select","select * from member where mem_usercode like '" + usercode + "'");
					if(rs.next())
					{
						textField_1.setText(rs.getString("mem_id"));
						JOptionPane.showMessageDialog(null, "�����ڵ带 �ؾ������ �����ڿ��� �����ٶ��ϴ�.","�˸��޽���",JOptionPane.INFORMATION_MESSAGE);
					}
					else
					{
						JOptionPane.showMessageDialog(null, "�˻��� ���̵� �����ϴ�. �ٽ� �Է��� �ֽʽÿ�.","�����޽���",JOptionPane.ERROR_MESSAGE);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		btnId.setToolTipText("PW \uCC3E\uAE30");
		btnId.setBounds(165, 127, 116, 23);
		contentPane.add(btnId);
		
		JLabel lblPw_1 = new JLabel("ID");
		lblPw_1.setFont(new Font("����", Font.PLAIN, 15));
		lblPw_1.setBounds(140, 174, 13, 18);
		contentPane.add(lblPw_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(165, 173, 116, 21);
		contentPane.add(textField_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("ID\uB97C \uC78A\uC9C0 \uC54A\uB3C4\uB85D \uD558\uC2DC\uC624!!");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setForeground(Color.RED);
		lblNewLabel_1_1.setBounds(135, 202, 146, 15);
		contentPane.add(lblNewLabel_1_1);
		
		ImageIcon icon4 = new ImageIcon(MainScreen.class.getResource("/image/images.png"));
		Image img4 = icon4.getImage();
		Image changeImg4 = img4.getScaledInstance(60, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon3 = new ImageIcon(changeImg4);
		JButton btnNewButton_1_2 = new JButton(changeIcon3);
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton_1_2.setToolTipText("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1_2.setBackground(Color.WHITE);
		btnNewButton_1_2.setBounds(12, 228, 36, 23);
		contentPane.add(btnNewButton_1_2);
	}
}
