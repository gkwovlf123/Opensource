import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.border.BevelBorder;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class OrderCheck extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	public static String driver, url;
	public static Connection conn;
	public static Statement stmt;
	public static ResultSet rs;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	public static void dbConnect() {
    	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		System.out.println("����̹� �˻� ����!");        
    	}catch(ClassNotFoundException e){
    		System.err.println("error = " + e);
    	}
        
    	
        url = "jdbc:odbc:parmacy db";
        conn = null;
        stmt = null;
        rs = null;
        String url = "jdbc:mysql://localhost/parmacy db?useUnicode=yes&characterEncoding=UTF-8";
        String sql = "select * From inventory";
		try {
         
            conn = DriverManager.getConnection(url,"root","apmsetup");

            stmt = conn.createStatement();

            rs = stmt.executeQuery(sql);
            
            System.out.println("�����ͺ��̽� ���� ����!");            
         
        }
        catch(Exception e) {
            System.out.println("�����ͺ��̽� ���� ����!");
        }
	}
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery(sql);
		} 
		else {
			stmt.executeUpdate(sql);
		}
	}
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public OrderCheck() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(OrderCheck.class.getResource("/image/document.png")));
		setTitle("\uBC1C\uC8FC\uBAA9\uB85D\uC870\uD68C");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 615, 465);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uBC1C\uC8FC\uBAA9\uB85D\uC870\uD68C");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 25));
		lblNewLabel.setBounds(0, 0, 603, 44);
		contentPane.add(lblNewLabel);
		
		SimpleDateFormat date1 = new SimpleDateFormat("YY�� MM�� dd��");
		String format_date1 = date1.format(System.currentTimeMillis());
		JLabel lblNewLabel_1_2 = new JLabel(format_date1);
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setFont(new Font("���� ����", Font.PLAIN, 14));
		lblNewLabel_1_2.setBounds(423, 22, 168, 15);
		contentPane.add(lblNewLabel_1_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 87, 560, 187);
		contentPane.add(scrollPane);
		
		
		String[] head = {"��ǰ ID", "��ǰ �̸�", "��������","����","����","����ȸ���ڵ�"};
		DefaultTableModel model = new DefaultTableModel(head,0);
			try {
				dbConnect();
				query("select", "select * from inventory where in_count<=10");
				while(rs.next()) {
					model.addRow(new Object[] {rs.getString("in_id"),
												rs.getString("in_name"),
												rs.getString("in_date"),
												rs.getString("in_count"),
												rs.getString("in_salary"),
												rs.getString("in_cusid")
												});
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			Main.dbDis();
		table = new JTable(model);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				TableModel data = table.getModel();
				String id = (String)data.getValueAt(row, 0);
				dbConnect();
				try {
					query("select", "select * from inventory where in_id like '" + id + "'");
					if(rs.next())
					{
						textField.setText(rs.getString("in_id"));
						textField_3.setText(rs.getString("in_name"));
						textField_2.setText(rs.getString("in_date"));
						textField_1.setText(rs.getString("in_count"));
						textField_4.setText(rs.getString("in_salary"));
						textField_6.setText(rs.getString("in_cusid"));
						textField_5.setText((rs.getString("in_comment")));
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		scrollPane.setViewportView(table);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setColumnSelectionAllowed(true);
		table.setCellSelectionEnabled(true);
		table.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		
		JLabel lblNewLabel_1 = new JLabel("\uC57D\uD488 ID");
		lblNewLabel_1.setBounds(4, 284, 39, 15);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(55, 281, 80, 21);
		contentPane.add(textField);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("\uAC1C\uC218");
		lblNewLabel_1_1_1.setBounds(147, 284, 24, 15);
		contentPane.add(lblNewLabel_1_1_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(175, 281, 80, 21);
		contentPane.add(textField_1);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("\uC81C\uC870\uC77C\uC790");
		lblNewLabel_1_1_1_1_1.setBounds(280, 284, 48, 15);
		contentPane.add(lblNewLabel_1_1_1_1_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(340, 281, 80, 21);
		contentPane.add(textField_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("\uC774\uB984");
		lblNewLabel_1_1.setBounds(19, 309, 24, 15);
		contentPane.add(lblNewLabel_1_1);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(55, 306, 80, 21);
		contentPane.add(textField_3);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("\uAC00\uACA9");
		lblNewLabel_1_1_1_1.setBounds(147, 309, 24, 15);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(175, 306, 80, 21);
		contentPane.add(textField_4);
		
		JButton btnNewButton = new JButton("\uBC1C\uC8FC\uD558\uAE30");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String id = textField.getText();
				String name = textField_3.getText();
				String date = textField_2.getText();
				String count = textField_1.getText();
				String price = textField_4.getText();
				String comment = textField_5.getText();
				String cusid = textField_6.getText();
				int c = Integer.parseInt(count);
				Date d = Date.valueOf(date);
				try {
					query("update", "update inventory set in_ID ='"+id+"', in_Name = '"+name +"', in_Date ='"+d+"', in_Count ='"+(c+c)+"', in_Salary ='"+price+"', in_Cusid ='"+cusid+"', in_comment ='"+comment+"' where in_ID like '"+id+"'");
					JOptionPane.showMessageDialog(null, "���������� ���ֵǾ����ϴ�!.", "�����޽���", JOptionPane.INFORMATION_MESSAGE);
					textField.setText("");
					textField_3.setText("");
					textField_2.setText("");
					textField_1.setText("");
					textField_4.setText("");
					textField_5.setText("");
					textField_6.setText("");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		btnNewButton.setToolTipText("\uBC1C\uC8FC\uD558\uAE30");
		btnNewButton.setBounds(465, 281, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uAC70\uB798\uCC98\uD655\uC778");
		btnNewButton_1.setToolTipText("\uAC70\uB798\uCC98\uD655\uC778");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AccountCheck_1().setVisible(true);
			}
		});
		btnNewButton_1.setBounds(465, 332, 97, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("\uC57D\uC758 \uC815\uBCF4");
		lblNewLabel_1_1_2.setBounds(0, 368, 52, 15);
		contentPane.add(lblNewLabel_1_1_2);
		
		ImageIcon icon4 = new ImageIcon(MainScreen.class.getResource("/image/images.png"));
		Image img4 = icon4.getImage();
		Image changeImg4 = img4.getScaledInstance(60, 30, Image.SCALE_SMOOTH);
		ImageIcon changeIcon3 = new ImageIcon(changeImg4);
		JButton btnNewButton_1_2 = new JButton(changeIcon3);
		btnNewButton_1_2.setToolTipText("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Login_MainScreen().setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton_1_2.setBackground(Color.WHITE);
		btnNewButton_1_2.setBounds(2, 393, 36, 23);
		contentPane.add(btnNewButton_1_2);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(55, 365, 394, 21);
		contentPane.add(textField_5);
		
		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("\uC81C\uC870\uD68C\uC0AC\uCF54\uB4DC");
		lblNewLabel_1_1_1_1_1_1.setBounds(267, 312, 72, 15);
		contentPane.add(lblNewLabel_1_1_1_1_1_1);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(340, 309, 80, 21);
		contentPane.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(381, 56, 116, 21);
		contentPane.add(textField_7);
		
		JLabel lblNewLabel_2 = new JLabel("\uAC80\uC0C9");
		lblNewLabel_2.setBounds(348, 59, 24, 15);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton_2 = new JButton("\uAC80\uC0C9");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String SearchData = textField_7.getText();
				model.setNumRows(0);
				try {
					query("select", "select * from inventory where in_count<=10 and in_name like '%"+SearchData+"%'");
					while(rs.next())
					{
						
						model.addRow(new Object[] {rs.getString("in_id"),
												   rs.getString("in_name"),
												   rs.getString("in_date"),
												   rs.getString("in_count"),
												   rs.getString("in_salary"),
												   rs.getString("in_cusid"),
											});
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Main.dbDis();
			}
		});
		btnNewButton_2.setBounds(509, 54, 63, 23);
		contentPane.add(btnNewButton_2);
	}
}
