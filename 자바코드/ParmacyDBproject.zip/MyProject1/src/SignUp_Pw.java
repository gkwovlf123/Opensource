import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.TextField;
import java.awt.Window;
import java.awt.FlowLayout;
import javax.swing.BoxLayout;
import javax.swing.JLabel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class SignUp_Pw extends JFrame implements ActionListener {

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public SignUp_Pw() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(SignUp_Pw.class.getResource("/image/padlock.png")));
		setTitle("\uBCF4\uC548\uD0A4\uD328\uB4DC");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 262, 300);
		getContentPane().setLayout(new GridLayout(0, 3, 0, 0));
		
		JButton btnNewButton_8 = new JButton("\uB4A4\uB85C");
		btnNewButton_8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				SignUp.textField_1.setText("");
				
				
			}
		});
		getContentPane().add(btnNewButton_8);
		
		JButton btnNewButton_11 = new JButton("Enter");
		btnNewButton_11.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				
			}
		});
		getContentPane().add(btnNewButton_11);
		int i;
		int num[] = new int[10];
		JButton button;
		Random ran = new Random();
		for(i=0;i<num.length;i++)
		{
			num[i] = ran.nextInt(10);
			for(int j=0;j<i;j++)
			{
				if(num[i]==num[j])
				{
					i--;
				}
			}
		}
		for(int k=0;k<10;k++)
		{
			button = new JButton(""+num[k]);
			button.addActionListener(this);
			getContentPane().add(button);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		int act = Integer.parseInt(e.getActionCommand());
		SignUp.textField_1.setText(SignUp.textField_1.getText()+act);
		
	
		
	}

}
