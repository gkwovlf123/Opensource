import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class MainScreen_Pw extends JFrame implements ActionListener {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public MainScreen_Pw() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainScreen_Pw.class.getResource("/image/padlock.png")));
		setTitle("\uBCF4\uC548\uD0A4\uD328\uB4DC");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 262, 300);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 3, 0, 0));
		
		JButton btnNewButton_1 = new JButton("\uB4A4\uB85C");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				MainScreen.txtpw.setText("");
			}
		});
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Enter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		contentPane.add(btnNewButton);
		int i;
		int num[] = new int[10];
		JButton button;
		Random ran = new Random();
		for(i=0;i<num.length;i++)
		{
			num[i] = ran.nextInt(10);
			for(int j=0;j<i;j++)
			{
				if(num[i]==num[j])
				{
					i--;
				}
			}
		}
		for(int k=0;k<10;k++)
		{
			button = new JButton(""+num[k]);
			button.addActionListener(this);
			getContentPane().add(button);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		int act = Integer.parseInt(e.getActionCommand());
		MainScreen.txtpw.setText(MainScreen.txtpw.getText()+act);
		
	
		
	}
	}

