-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- 호스트: localhost
-- 처리한 시간: 20-11-25 21:26 
-- 서버 버전: 5.1.41
-- PHP 버전: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 데이터베이스: `parmacy db`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `Cus_id` int(11) NOT NULL,
  `Cus_name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `Cus_address` varchar(20) CHARACTER SET utf8 NOT NULL,
  `Cus_Number` varchar(20) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`Cus_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- 테이블의 덤프 데이터 `customer`
--

INSERT INTO `customer` (`Cus_id`, `Cus_name`, `Cus_address`, `Cus_Number`) VALUES
(1, '한국비엠에스제약', '서울', '01012345678'),
(2, '한풍제약', '서울', '01045647897'),
(3, '피케이원팜', '서울', '01023456789'),
(4, 'MH헬스케어', '경기도', '01034567891'),
(5, '경보제약', '경기도', '01045678912'),
(6, '경인제약', '경기도', '01056789123'),
(7, '경풍약품', '부산', '01067891234'),
(8, '국전약품', '부산', '01078912345'),
(9, '그린제약', '부산', '01089123456'),
(10, '화인약품', '부산', '01091234567');

-- --------------------------------------------------------

--
-- 테이블 구조 `inventory`
--

CREATE TABLE IF NOT EXISTS `inventory` (
  `in_ID` int(2) NOT NULL,
  `in_Name` varchar(50) NOT NULL,
  `in_Date` date NOT NULL,
  `in_Count` int(4) NOT NULL,
  `in_Salary` varchar(10) NOT NULL,
  `in_Cusid` varchar(2) NOT NULL,
  `in_comment` varchar(200) NOT NULL,
  PRIMARY KEY (`in_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `inventory`
--

INSERT INTO `inventory` (`in_ID`, `in_Name`, `in_Date`, `in_Count`, `in_Salary`, `in_Cusid`, `in_comment`) VALUES
(1, '바라크루드시럽', '2020-11-21', 21, '10000', '1', '활동성 바이러스의 복제가 확인되고; 혈청 아미노전이효소(ALT 또는 AST)의 지속적 상승 또는 조직학적으로 활동성 질환이 확인된 성인(16세 이상)의 만성 B형 간염바이러스 감염의 치료'),
(2, '바이덱스정', '2020-11-21', 20, '7000', '1', '다른 항레트로바이러스 제제와 병용하여 HIV-1 감염환자의 치료. 항레트로바이러스 요법에 의한 임상적 유용성은 그 기간이 제한적이다.   '),
(3, '세프질시럽', '2020-11-21', 22, '5000', '2', '이 약은 다음과 같은 감수성 균주에 의한 경증 및 중등도의 감염증 환자의 치료에 사용한다 : 인두염/편도염, 중이염,급성부비동염'),
(4, '엔테카비르정', '2020-11-21', 20, '7000', '2', '만성 B형 간염의 치료'),
(5, '가메레온과립', '2020-10-01', 20, '10000', '3', '야제증, 경풍'),
(6, '가스키환', '2020-10-01', 20, '5000', '3', '식체, 곽란, 소화불량'),
(7, '갈미정', '2020-10-02', 10, '5000', '5', '비교적 체력이 있고 두통,어깨가 뻣뻣한 증세가 수반하는 다음 증세 : 비염, 비루, 비폐쇄, 부비강염(축농증)'),
(8, '건치환', '2020-10-03', 20, '7000', '5', '치통의 완화'),
(9, '굿모닝에프과립', '2020-06-10', 10, '5000', '10', '변비, 변비에 따른 다음 증상의 완화 : 식욕부진(식욕감퇴), 복부팽만, 장내 이상발효, 치질'),
(10, '화니콜정', '2020-06-10', 20, '10000', '10', '감기의 제증상(콧물, 코막힘, 재채기, 인후통, 가래, 오한, 발열, 두통, 관절통, 근육통)의 완화'),
(11, '기가스탑정', '2020-06-10', 9, '5000', '10', '감기의 제증상(인후통, 기침, 가래, 오한, 발열, 두통, 관절통, 근육통)의 완화 '),
(12, '비앤콜정', '2020-06-10', 20, '5000', '4', '감기의 제증상(콧물, 코막힘, 재채기, 인후통, 오한, 발열, 두통, 관절통, 근육통)'),
(13, '시로파정', '2020-06-11', 10, '10000', '4', '류마티양 관절염, 골관절염(퇴행성 관절질환), 강직성 척추염, 건염, 급성통풍, 월경곤란증 '),
(14, '아타펜정', '2020-06-12', 10, '7000', '6', '두통, 치통, 발치후 동통, 인후통, 귀의 통증, 관절통, 신경통, 요통, 근육통, 견통, '),
(15, '크라젠정', '2020-06-13', 20, '5000', '7', '류마티양 관절염, 근육통, 신경통, 외상후 . 수술후 동통, 두통, 치통, 이통, 월경통'),
(16, '국전살리실산', '2020-01-04', 20, '7000', '8', '감기, 인후염'),
(17, '그로신정', '2020-01-04', 10, '5000', '9', '비뇨기계의 경련 및 통증 : 신염성 산통 소화관 및 담도계의 기능장애에 의한 통증 임신중 수축의 보조치료'),
(18, '그린솔트에프액', '2020-01-04', 20, '10000', '9', '찰과상, 절상, 창상, 수지의 살균소독, 치질인 경우의 항문 살균소독.'),
(19, '빨간약', '2020-11-21', 5, '2000', '7', '엄청난 소독약'),
(20, '만병통치약', '2020-11-21', 1, '100000', '7', '궁극의 만병통치약'),
(21, '가나릴정', '2020-05-10', 21, '10000', '6', ' 기능성소화불량으로 인한 소화기증상(복부팽만, 상복부통, 식욕부진, 속쓰림, 구역, 구토)'),
(22, '가나메드정', '2020-11-01', 10, '5000', '4', '기능성소화불량으로 인한 소화기증상(복부팽만, 상복부통, 식욕부진, 속쓰림, 구역, 구토)');

-- --------------------------------------------------------

--
-- 테이블 구조 `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `mem_ID` varchar(20) NOT NULL COMMENT '아이디',
  `mem_Pw` varchar(10) NOT NULL COMMENT '비밀번호',
  `mem_EMail` varchar(30) NOT NULL COMMENT '이메일',
  `mem_usercode` varchar(11) NOT NULL,
  PRIMARY KEY (`mem_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- 테이블의 덤프 데이터 `member`
--

INSERT INTO `member` (`mem_ID`, `mem_Pw`, `mem_EMail`, `mem_usercode`) VALUES
('user01', '1111', 'user01@naver.com', '8764'),
('admin', '1234', 'admin@google.com', '7436'),
('user02', '2222', 'user02@naver.com', '9446');

-- --------------------------------------------------------

--
-- 테이블 구조 `noticeboard`
--

CREATE TABLE IF NOT EXISTS `noticeboard` (
  `n_title` varchar(300) NOT NULL,
  `n_string` varchar(1000) NOT NULL,
  `n_date` date NOT NULL,
  `n_user` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='게시판';

--
-- 테이블의 덤프 데이터 `noticeboard`
--

INSERT INTO `noticeboard` (`n_title`, `n_string`, `n_date`, `n_user`) VALUES
('유저코드', '까먹음', '2020-11-25', 'user1'),
('질문', '회원가입 어떻게해요??', '2020-11-25', '비회원'),
('ID찾기 질문', '유저코드를 모르겠어요ㅠㅠ', '2020-11-25', '비회원');
